#!/bin/bash
wget --no-cache https://raw.githubusercontent.com/Panther-X/PantherDashboard/main/version -O /var/dashboard/update
